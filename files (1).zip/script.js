// ---------- 3. Light / Dark mode ----------
document.getElementById("theme-btn").addEventListener("click", function () {
  document.body.classList.toggle("dark");
});

// ---------- 8. Opening status ----------
var hour = new Date().getHours();
var statusText = document.getElementById("status");
if (hour >= 8 && hour < 20) {
  statusText.textContent = "We are Open!";
  statusText.style.color = "green";
} else {
  statusText.textContent = "Closed - Open at 8 AM";
  statusText.style.color = "red";
}

// ---------- 6. Read More toggle ----------
var moreText = document.getElementById("more-text");
var readBtn = document.getElementById("read-btn");
moreText.style.display = "none"; // hidden at start
readBtn.addEventListener("click", function () {
  if (moreText.style.display === "none") {
    moreText.style.display = "block";
    readBtn.textContent = "Read Less";
  } else {
    moreText.style.display = "none";
    readBtn.textContent = "Read More";
  }
});

// ---------- 2. Table row highlight ----------
var rows = document.querySelectorAll("#menu-table tbody tr");
rows.forEach(function (row) {
  row.addEventListener("mouseover", function () {
    row.style.backgroundColor = "#c68b59";
  });
  row.addEventListener("mouseout", function () {
    row.style.backgroundColor = "";
  });
});

// ---------- 4. Order total ----------
var items = document.querySelectorAll(".item");
var total = document.getElementById("total");
items.forEach(function (box) {
  box.addEventListener("change", function () {
    var sum = 0;
    items.forEach(function (b) {
      if (b.checked) {
        sum = sum + parseInt(b.value);
      }
    });
    total.textContent = "Total: $" + sum;
  });
});

// ---------- 7. Category filter ----------
var filterButtons = document.querySelectorAll(".filter-btn");
filterButtons.forEach(function (btn) {
  btn.addEventListener("click", function () {
    var choice = btn.dataset.filter;
    rows.forEach(function (row) {
      if (choice === "all" || row.dataset.category === choice) {
        row.style.display = "";
      } else {
        row.style.display = "none";
      }
    });
  });
});

// ---------- 9. Character counter ----------
var notes = document.getElementById("special-notes");
var counter = document.getElementById("counter");
notes.addEventListener("input", function () {
  var left = 100 - notes.value.length;
  counter.textContent = left + " characters remaining";
});

// ---------- 1 & 5. Form submit + age check ----------
var form = document.getElementById("feedback-form");
form.addEventListener("submit", function (e) {
  e.preventDefault(); // stop page refresh

  var username = document.getElementById("username").value;
  var email = document.getElementById("email").value;
  var message = document.getElementById("message");
  var discountMsg = document.getElementById("discount-msg");

  if (username !== "" && email !== "") {
    message.textContent = "Thank you for visiting, " + username + "! We will contact you at " + email + ".";
  } else {
    message.textContent = "Please fill in your username and email.";
  }

  // Age check (type conversion)
  var birthYear = parseInt(document.getElementById("birth-year").value);
  if (isNaN(birthYear)) {
    discountMsg.textContent = "";
  } else {
    var age = 2026 - birthYear;
    if (age >= 60) {
      discountMsg.textContent = "You qualify for the Senior Discount!";
    } else if (age >= 18 && age <= 25) {
      discountMsg.textContent = "You qualify for the Student Discount!";
    } else {
      discountMsg.textContent = "Sorry, no discount available for your age.";
    }
  }
});
